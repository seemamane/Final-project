package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForDatabase implements IFilmDao{

	private List<Film> film_repository=new ArrayList<>();
	
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		DatabaseConnection connection = new DatabaseConnection();
		Connection newconnection=  connection.getConnection();

		boolean flag=false;
		String sql = "select * from LANGUAGE";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Language language = new Language();
				
				language.setLanguage_Id(rs.getInt(1));
				language.setLanguage_Name(rs.getString(2));
				languages.add(language);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		/*languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marathi"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));*/
		
		
		return languages;
	}

	public List<Category> getCategory(){
		
		List<Category> categorys=new ArrayList<>();
		
		
		DatabaseConnection conn = new DatabaseConnection();
		Connection newconnection=  conn.getConnection();

		boolean flag=false;
		String sql = "select * from Category";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Category category = new Category();
				
			   category.setCategory_Id(rs.getInt(1));
			   category.setCategory_Name(rs.getString(2));
			
			   categorys.add(category);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		/*
		category.add(new Category(1, "Action"));
		category.add(new Category(2, "Comedy"));
		category.add(new Category(3, "Drama"));
		category.add(new Category(4, "Sci-Fi"));
		category.add(new Category(5, "Magic"));
				
		*/
		
		return categorys;
	}

	@Override
	public void addFilm(Film film) {
		
		
		DatabaseConnection connection = new DatabaseConnection();
		Connection newconnection=  connection.getConnection();
		
		String insertFilm="insert into film(Title,Description,ReleaseYear,OriginalLanguage_ID,RentalDuration,LENGTH,ReplacementCost,Ratings,SpecialFeatures,Category_ID)"
				+"values(?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pst;
		try {
			
			pst = newconnection.prepareStatement(insertFilm);
			
			pst.setString(1, film.getTitle());
			pst.setString(2, film.getDescription());			
			pst.setDate(3, new java.sql.Date(film.getRelease_Year().getTime()));
			pst.setInt(4,film.getOriginal_Langauges().getLanguage_Id());
			pst.setDate(5, new java.sql.Date(film.getRental_Duration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7,film.getReplacement_Cost());
			pst.setInt(8, film.getRating());
			pst.setString(9, film.getSpecial_Features());
			pst.setInt(10, film.getCategory().getCategory_Id());
			
			//pst.setInt(11, film.getActors());
			
			
			int count=pst.executeUpdate();
			
			System.out.println(count);
			
			
			if(count>0){
				
				//insert into third party tables
				int filmId=0;
				
				String sql1="select * from film order by film_id desc limit 1";
						
				PreparedStatement stmt = newconnection.prepareStatement(sql1);
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()){
						
					filmId = rs.getInt(1);
				}
				
				String sqlInsertActor="insert into film_actors(filmId,actor_id) values(?,?)";
				pst = newconnection.prepareStatement(sqlInsertActor);
				
				//getting all the actors in the film
				Set<Actor> actors = film.getActors();				
				for(Actor act: actors){
					pst.setInt(1, filmId );
					pst.setInt(2, act.getActor_Id());
					
					count=pst.executeUpdate();
				}
				String sqlInsertLang="insert into film_language(filmId,language_id) values(?,?)";
				pst = newconnection.prepareStatement(sqlInsertLang);
				
				//getting all the other languages
				List<Language> languages = film.getLanguages();		
				for(Language lang: languages){
					pst.setInt(1, filmId );
					pst.setInt(2, lang.getLanguage_Id());
					
					count=pst.executeUpdate();
				}
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<Film> getAllFilms() {
	
		
		List<Film> allFilms=new ArrayList<>();
		DatabaseConnection connection=new DatabaseConnection();
		Connection conn=connection.getConnection();
		
		
		String selectAllFilms = "select * from film";
		PreparedStatement stmt;
		
		try {
			stmt=conn.prepareStatement(selectAllFilms);
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()){
				
				
				Film film=new Film();
				
				
				film.setFilmId(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setRelease_Year(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				
				//film.setOriginal_Langauges(rs.getInt(5));
				film.setRental_Duration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				film.setLength(rs.getInt(7));
				film.setReplacement_Cost(rs.getInt(8));
				film.setRating(rs.getInt(9));
				film.setSpecial_Features(rs.getString(10));
				
			
				//allFilms.add(film);
				
				String categorySql="select * from Category where category_id="+rs.getString(11);
				stmt=conn.prepareStatement(categorySql);
				ResultSet rs1=stmt.executeQuery();
				Category category=new Category();
				while(rs1.next()){
					category.setCategory_Name(rs.getString(2));
					film.setCategory(category);
				}
				
				String originalLangSql="select * from language where language_id="+rs.getString(5);			
				stmt=conn.prepareStatement(originalLangSql);
				ResultSet rs2=stmt.executeQuery();
				Language language=new Language();
				while(rs2.next()){
				language.setLanguage_Name(rs2.getString(2));
				film.setOriginal_Langauges(language);
				}
				
				//Other Languages
				String subsql="select language_id from film_language where filmId="+rs.getInt(1);
				System.out.println(rs.getInt(1));
				stmt=conn.prepareStatement(subsql);
			    ResultSet rs3=stmt.executeQuery();
			    List<Language> languages=new ArrayList<>();
				while(rs3.next())
				{
											
					String subsql1="select language_name from language where language_id="+rs3.getInt(1);
					PreparedStatement pst2=conn.prepareStatement(subsql1);
					ResultSet rs4=pst2.executeQuery();
					while(rs4.next()){
						Language langs=new Language();
						langs.setLanguage_Id(rs3.getInt(1));
						langs.setLanguage_Name(rs4.getString(1));
						languages.add(langs);
						
					}
				}
				film.setLanguages(languages);
				
				//Actors
				String subsql1="select actor_id from film_actors where filmId="+rs.getInt(1);
				
				stmt=conn.prepareStatement(subsql1);
				ResultSet rs5=stmt.executeQuery();
				Set<Actor> actors=new HashSet<>();
			   
				while(rs5.next())
				{
					String subsql11="select firstName,lastName from actor where Actor_id="+rs5.getInt(1);
					PreparedStatement pst2=conn.prepareStatement(subsql11);
					ResultSet rs6=pst2.executeQuery();
					while(rs6.next()){
						Actor actr=new Actor();
						actr.setActor_First_Name(rs6.getString(1));
						actr.setActor_Last_Name(rs6.getString(2));
						actr.setActor_Id(rs5.getInt(1));
						actors.add(actr);
						
					}
				}
				film.setActors(actors);
				film.setLanguages(languages);
				System.out.println(film);
				allFilms.add(film);
				
				
			}
			
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return allFilms;
		}
	
	

	
	
	
	

	@Override
	public int removeFilm(int id) {
		
		DatabaseConnection connection=new DatabaseConnection();
		Connection conn=connection.getConnection();
		int count=0;
		
		String deleteFromFilm="delete from film where film_id=?";
		String deleteFromThirdParty1="delete from film_language where filmId=?";
		String deleteFromThirdParty2="delete from film_actors where filmId=?";
		try {
			PreparedStatement pst=conn.prepareStatement(deleteFromFilm);
			pst.setInt(1, id);
		    count=pst.executeUpdate();
		    
		    
		    
		    PreparedStatement pst1=conn.prepareStatement(deleteFromThirdParty1);
		    pst1.setInt(1, id);
		    count=pst1.executeUpdate();
		    
		    
		    PreparedStatement pst2=conn.prepareStatement(deleteFromThirdParty2);
		    pst2.setInt(1, id);
		    count=pst2.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return count;
		
	}

	@Override
	public List<Film> searchFilm(Film film) {
		
		System.out.println(film);
		DatabaseConnection connection= new DatabaseConnection();
		
		Connection conn=connection.getConnection();
		int count=0;
		System.out.println(film);
		String searchQuery="select * from film where ";
		ArrayList<Film> films=new ArrayList<Film>();
		//System.out.println(film);
		if(film!=null)
		{
			if(film.getFilmId()>0)
			{
				
				searchQuery+="film_id="+film.getFilmId();
				
				count=1;
			}
			System.out.println(searchQuery);
			if(film.getTitle()!=null)
			{
				if(count==1)
				{
					searchQuery+=" and Title='"+film.getTitle()+"'";
				}
				else
				{
					searchQuery+=" Title='"+film.getTitle()+"'";
				}
				count=2;
			}
		

			if(film.getRating()>0)
			{
				if(count==1||count==2)
				{
					searchQuery+=" and Ratings="+film.getRating();
				}
				else
				{
					searchQuery+=" Ratings="+film.getRating();
				}
				count=3;
				
			}
			if(film.getActors()!=null)
			{
				Actor actor=new Actor();
			//	Set<Actor> act=film.getActors();
				Set<Actor> act = film.getActors();
				for(Actor a:act)
					actor=a;
				if(count==1||count==2||count==3)
				{
					searchQuery+=" and filmId In(Select filmId from film_actors where actor_id="+actor.getActor_Id()+")";
					
				}else
				{
					searchQuery+=" filmId In(Select filmId from film_actors where actor_id="+actor.getActor_Id()+")";
				}
				count=4;
			}
			if(film.getLanguages()!=null)
			{
				Language lang=new Language();
				List<Language> langs=film.getLanguages();
			
				for(Language l:langs)
					lang=l;
				if(count==1||count==2||count==3||count==4)
				{
					searchQuery+=" and( filmId In(Select filmId from film_language where language_id="+lang.getLanguage_Id()+") or filmid In( Select film_id from film where OriginalLanguage_ID="+lang.getLanguage_Id()+"))";
					
				}else
				{
					searchQuery+=" ( filmId In(Select filmId from film_language where language_id="+lang.getLanguage_Id()+") or filmid In (Select film_id from film where OriginalLanguage_ID="+lang.getLanguage_Id()+"))";
				
				}
				count=5;
			}
		
			 
			if(film.getRelease_Year()!=null)
			{
				if(count==1||count==2||count==3||count==4||count==5)
				{
					searchQuery+=" and releaseYear='"+new java.sql.Date(film.getRelease_Year().getTime())+"'";
				}
				else
				{
					searchQuery+="  releaseYear='"+new java.sql.Date(film.getRelease_Year().getTime())+"'";
				}
				count=6;
			}
			
			try {
				PreparedStatement stmt11=conn.prepareStatement(searchQuery);
				//System.out.println(searchQuery + "Hi");
				ResultSet rs=stmt11.executeQuery();
		while(rs.next()){
				Film film1=new Film();
				film1.setFilmId(rs.getInt(1));
				film1.setTitle(rs.getString(2));
				film1.setDescription(rs.getString(3));
				film1.setRelease_Year(rs.getDate(4));
		
				System.out.println(film1 + " 1");
				String subsql;
				subsql="select language_name from LANGUAGE where language_id="+rs.getInt(5);
				PreparedStatement pst1=conn.prepareStatement(subsql);
				ResultSet rs3=pst1.executeQuery();
				Language lang=new Language();
				if(rs3.next())
				{
					lang.setLanguage_Id(rs.getInt(5));
					lang.setLanguage_Name(rs3.getString(1));
				}
				film1.setOriginal_Langauges(lang);
				film1.setRental_Duration(rs.getDate(6));
				film1.setLength(rs.getInt(7));
				film1.setReplacement_Cost(rs.getInt(8));
				film1.setRating(rs.getInt(9));
				film1.setSpecial_Features(rs.getString(10));
				
				System.out.println(film1 + " 2");
				
				subsql="select Category_name from Category where category_id="+rs.getInt(11);
				PreparedStatement pst3=conn.prepareStatement(subsql);
			    rs3=pst3.executeQuery();
				if(rs3.next())
				{
					Category cat=new Category();
					cat.setCategory_Id(rs.getInt(11));
					cat.setCategory_Name(rs3.getString(1));
					film1.setCategory(cat);
				}
				
				subsql="select language_id from film_language where filmId="+rs.getInt(1);
				System.out.println(rs.getInt(1));
				pst3=conn.prepareStatement(subsql);
			    rs3=pst3.executeQuery();
			    List<Language> languages=new ArrayList<>();
				while(rs3.next())
				{
											
					String subsql1="select language_name from LANGUAGE where language_id="+rs3.getInt(1);
					PreparedStatement pst2=conn.prepareStatement(subsql1);
					ResultSet rs1=pst2.executeQuery();
					while(rs1.next()){
						Language langs=new Language();
						langs.setLanguage_Id(rs3.getInt(1));
						langs.setLanguage_Name(rs1.getString(1));
						languages.add(langs);
						
					}
				}
				film1.setLanguages(languages);
				subsql="select actor_id from film_actors where filmId="+rs.getInt(1);
			
				pst3=conn.prepareStatement(subsql);
			    rs3=pst3.executeQuery();
			   // Set<Actor> actors=new HashSet<>();
			    Set<Actor> actors = new HashSet<>();
				while(rs3.next())
				{
					String subsql1="select FirstName,LastName from actor where Actor_id="+rs3.getInt(1);
					PreparedStatement pst2=conn.prepareStatement(subsql1);
					ResultSet rs1=pst2.executeQuery();
					while(rs1.next()){
						Actor actr=new Actor();
						actr.setActor_First_Name(rs1.getString(1));
						actr.setActor_Last_Name(rs1.getString(2));
						actr.setActor_Id(rs3.getInt(1));
						actors.add(actr);
						
					}
				}
				film1.setActors(actors);
				film1.setLanguages(languages);
		
				System.out.println(film1 + " 3");
				films.add(film1);
		}
			}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
		
		return films;
	}

	
	
	
	
	
	
	
	
	@Override
	public Film updateRecord(int fID) {
		
		DatabaseConnection connection=new DatabaseConnection();
		Connection conn=connection.getConnection();
		//Film film;
		Film film=new Film();
		String filmRecordSql="select * from film where film_id=?";
		
		try {
			PreparedStatement pst=conn.prepareStatement(filmRecordSql);
			pst.setInt(1, fID);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				
				
				//film=new Film();
				
				
				film.setFilmId(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setRelease_Year(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				
				//film.setOriginal_Langauges(rs.getInt(5));
				film.setRental_Duration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				film.setLength(rs.getInt(7));
				film.setReplacement_Cost(rs.getInt(8));
				film.setRating(rs.getInt(9));
				film.setSpecial_Features(rs.getString(10));
				
			
				//allFilms.add(film);
				
				String categorySql="select * from Category where category_id="+rs.getString(11);
				PreparedStatement stmt=conn.prepareStatement(categorySql);
				ResultSet rs1=stmt.executeQuery();
				Category category=new Category();
				while(rs1.next()){
					category.setCategory_Name(rs.getString(2));
					film.setCategory(category);
				}
				
				String originalLangSql="select * from language where language_id="+rs.getString(5);			
				stmt=conn.prepareStatement(originalLangSql);
				ResultSet rs2=stmt.executeQuery();
				Language language=new Language();
				while(rs2.next()){
				language.setLanguage_Name(rs2.getString(2));
				film.setOriginal_Langauges(language);
				}
				
				//Other Languages
				String subsql="select language_id from film_language where filmId="+rs.getInt(1);
				System.out.println(rs.getInt(1));
				stmt=conn.prepareStatement(subsql);
			    ResultSet rs3=stmt.executeQuery();
			    List<Language> languages=new ArrayList<>();
				while(rs3.next())
				{
											
					String subsql1="select language_name from language where language_id="+rs3.getInt(1);
					PreparedStatement pst2=conn.prepareStatement(subsql1);
					ResultSet rs4=pst2.executeQuery();
					while(rs4.next()){
						Language langs=new Language();
						langs.setLanguage_Id(rs3.getInt(1));
						langs.setLanguage_Name(rs4.getString(1));
						languages.add(langs);
						
					}
				}
				film.setLanguages(languages);
				
				//Actors
				String subsql1="select actor_id from film_actors where filmId="+rs.getInt(1);
				
				stmt=conn.prepareStatement(subsql1);
				ResultSet rs5=stmt.executeQuery();
				Set<Actor> actors=new HashSet<>();
			   
				while(rs5.next())
				{
					String subsql11="select firstName,lastName from actor where Actor_id="+rs5.getInt(1);
					PreparedStatement pst2=conn.prepareStatement(subsql11);
					ResultSet rs6=pst2.executeQuery();
					while(rs6.next()){
						Actor actr=new Actor();
						actr.setActor_First_Name(rs6.getString(1));
						actr.setActor_Last_Name(rs6.getString(2));
						actr.setActor_Id(rs5.getInt(1));
						actors.add(actr);
						
					}
				}
				film.setActors(actors);
				film.setLanguages(languages);
				System.out.println(film);
				//allFilms.add(film);
				
				
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return film;
	}

	@Override
	public int updateFilm(int id, Film film) {
		int  count=0;
		DatabaseConnection connection=new DatabaseConnection();
		Connection conn=connection.getConnection();
		String sql="update film set Title=?,Description=?,ReleaseYear=?,OriginalLanguage_ID=?,RentalDuration=?,LENGTH=?,ReplacementCost=?,Ratings=?,SpecialFeatures=?,Category_ID =? where film_id=?";
		String sql1="delete from film_language where filmId=?";
		String sql4="delete from film_actors where filmId=?";
		

		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			//pst.setString(1, film.getTitle());
			pst.setString(1, film.getTitle());
			pst.setString(2, film.getDescription());
			pst.setDate(3, new Date(film.getRelease_Year().getTime()));
			int language=film.getOriginal_Langauges().getLanguage_Id();
			pst.setInt(4, language);
			pst.setDate(5, new Date(film.getRental_Duration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7,film.getReplacement_Cost());
			
			pst.setInt(8,film.getRating());
			pst.setString(9,film.getSpecial_Features());
			int category=film.getCategory().getCategory_Id();
			pst.setInt(10,category);
			pst.setInt(11, id);
			
			count=pst.executeUpdate();
			
			
			//delete from film_language
			PreparedStatement pst1=conn.prepareStatement(sql1);
			pst1.setInt(1, id);
		    count=pst1.executeUpdate();
		    
		  //delete from film_actors
			PreparedStatement pst4=conn.prepareStatement(sql4);
			pst4.setInt(1, id);
		    count=pst4.executeUpdate();
		    
		    //insert into film_language
		  //insert into film_languages
			String sql2="insert into film_language values(?,?)";
			PreparedStatement pst2=conn.prepareStatement(sql2);
		     List<Language> lang=film.getLanguages();
		     System.out.println(lang);
			for(Language lang1:lang){
			pst2.setInt(1, id);
			pst2.setInt(2,lang1.getLanguage_Id());
		    count=pst2.executeUpdate();
			}
		    
			String sql3="insert into film_actors values(?,?)";
			PreparedStatement pst3=conn.prepareStatement(sql3);
		    Set<Actor> actor=film.getActors();
			for(Actor act1:actor){
			pst3.setInt(1, id);
			pst3.setInt(2,act1.getActor_Id());
			 count=pst3.executeUpdate();
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
		return count;
	}

	
	


}
