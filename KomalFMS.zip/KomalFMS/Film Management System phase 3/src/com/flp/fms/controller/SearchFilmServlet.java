package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;
import com.flp.fms.view.UserInteraction;


public class SearchFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
		IFilmService filmService =new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		List<Language> languages=filmService.getLanguages();
		Set<Actor>actors=actorService.getActors();
		List<Category>category=filmService.getCategory();
		
		
		PrintWriter out=response.getWriter();
		
		
		out.println("<html>");
		out.println("<head><title>Search Film</title>");
		out.println("<script type='text/javascript' src=''></script>"
		
		+ "<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
	    + "<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
		+"  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
		+ " <link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
		+ "<script type='text/javascript' src='scripts/dateSelector.js'></script>");
		/*+"<!-- Javascript -->"
		+"    <script>"
		
		+"       $(function() {"
		  +"       $( '#datepicker1' ).datepicker({maxDate:'0', dateFormat:'dd-MM-yy'});"
		    +"    $( '#datepicker1' ).datepicker('show');"
		      +"});"
		       + "</script>");*/
		
		out.println("</head>"
		+"<body>");
		
		out.println("<form name='searchForm' action='SearchServlet'");
		out.println("<div>");
		out.println("<table>");
		
		out.println("<tr>"+ "<td>");
		out.println("By FilmId:<input type='textbox' name='ByFilmId'/> ");
		out.println("</td>"+ "</tr>");
		
		out.println("<tr>"+ "<td>");
		out.println("By Rating:<input type='textbox' name='ByRating'/> ");
		out.println("</td>"+ "</tr>");
		
		out.println("<tr>"+"<td>Release Date:<input type='text' id='datepicker1' name='releaseYear' size='20'>"
	    +"</td> "+"	</tr>");
		
		out.println("<tr>"+ "<td>");
	    out.println("By Title:<input type='textbox' name='ByTitle'/> ");
		out.println("</td>"+ "</tr>"
	    
		+ "<tr>" + "<td>");
		out.println("By Language:<select name='ByLanguage'>"
	    +"<option value='0'>--Select--</option>");
	    for(Language lang:languages){
	    out.println("<option value='"+ lang.getLanguage_Id()+"'>"
	    +lang.getLanguage_Name()+ "</option>");	
		   }
	    out.println("</select>");
	    out.println("</td></tr>");
	    
	
		out.println("<tr><td>");
		out.println("By Actor:<select name='ByActor'>"
		+ "<option value='0'>--Select--</option>");
		for(Actor act: actors)
		{
		out.println("<option value='"+act.getActor_Id()+"'>"
		+act.getActor_First_Name()+" "+act.getActor_First_Name()
		+"</option>");
		}
		
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>"
				+ "<tr>"
				+ "<td>"
				+ "<input type='submit' value='Search Film' name='search'>"
				+ "</td>"
				+ "</tr>"
				);

		out.println("</table>");
		out.println("</div>");
	
	
	
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
		
}
