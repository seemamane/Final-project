package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;


public class UpdateFilmServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	
		
		 int filmId=Integer.parseInt(request.getParameter("film_id"));
		  FilmServiceImpl filmService=new FilmServiceImpl();
		  Film film=new Film();
		  
		  film.setTitle(request.getParameter("title"));
		  film.setDescription(request.getParameter("desc"));
		  //film.setRelease_Year(new Date(request.getParameter("releaseYear")));
		  
		  String releaseYear=request.getParameter("releaseYear");
		  Date releaseYear1=new Date(releaseYear);
		  film.setRelease_Year(releaseYear1);
		  
		  Language lang=new Language();
		  lang.setLanguage_Id(Integer.parseInt(request.getParameter("originalLang")));
		  film.setOriginal_Langauges(lang);
		  
		 // film.setRental_Duration(new Date(request.getParameter("rentalduration")));
		  String rentalDuration=request.getParameter("rentalduration");
		  Date rentalDuration1=new Date(rentalDuration);
		  film.setRental_Duration(rentalDuration1);
			
		  film.setLength(Integer.parseInt(request.getParameter("length")));
		  film.setReplacement_Cost(Integer.parseInt(request.getParameter("cost")));
		  film.setRating(Integer.parseInt(request.getParameter("rating")));
		  film.setSpecial_Features(request.getParameter("specialFeatures"));
		  
		  
		  Category category=new Category();
		  category.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		  film.setCategory(category);
		  
		
		  
		  String [] actors=request.getParameterValues("actor");
		  Set<Actor> actor1=new HashSet<>();
		  
		  for(String str:actors){
			  Actor act=new Actor();
			  act.setActor_Id(Integer.parseInt(str));
			  actor1.add(act);
			  
		  }
		   film.setActors(actor1);
		   
		  
		   String [] lang1=request.getParameterValues("Lang");
		   List<Language> langs=new ArrayList<>();
		   for(String lang2:lang1)
		   {
			   Language lang3=new Language();
			   lang3.setLanguage_Id(Integer.parseInt(lang2));
			   langs.add(lang3);
		   }
		   film.setLanguages(langs);
		   System.out.println("update");
		   System.out.println(filmId);
		   System.out.println(film);
		   
		  int c= filmService.updateFilm(filmId,film);
		  if(c>0)
			 
			  
			  response.sendRedirect("UpdateFilm");
	}

}
