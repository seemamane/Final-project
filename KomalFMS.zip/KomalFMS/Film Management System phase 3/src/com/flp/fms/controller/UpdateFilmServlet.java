package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;


public class UpdateFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateFilmServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out=response.getWriter();
		FilmServiceImpl filmserviceimpl=new FilmServiceImpl();
		ActorServiceImpl actorserviceimpl=new ActorServiceImpl();
		int Fid=Integer.parseInt(request.getParameter("FilmId"));
		
		Film film=filmserviceimpl.updateRecord(Fid);
		
		
		
		List<Category> category=filmserviceimpl.getCategory();
		System.out.println(film);
		
		out.print("<html>");
		out.print("<body>");

		out.print("<head>"
				
			+"<link rel='stylesheet' type='text/css' href='css/mystyles.css'>"	
			+ "<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
			+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
			+ "<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
			+ "<script type='text/javascript' src='script/FormValidation.js'></script>"
			+ "<link type='text/css' rel='stylesheet' href='css/MyStyle.css'>"
			+ "<script>$(function() {$( '#datepicker' ).datepicker();});</script>"
			+ "<script>$(function() {$( '#datepicker1' ).datepicker();});</script>"
			+ "<script>$(document).ready(function() {$('#start_datepicker')datepicker();$('#end_datepicker').datepicker();});</script>"
			+ "</head>");
		out.print("<form name='film' method='post'action='UpdateFilmServlet1'>");
		out.print("<h1 align='center'>Add Film Details</h1>");
		out.println("<table>" + 
				"<tr>" +
				"<td>Film Title:</td>" +
				"<td><input type='text' name='title' value='"+film.getTitle()+"' onmouseout='return isValidTitle()'>" +
				"<div id='titleDiv'class='errMsg'></div></td>" +
				"</tr>");
		out.print("<tr>" 
				+ "<td>Desciption:</td>"
				+ "<td><textarea rows='4' name='desc'cols='25'>"+film.getDescription()+"</textarea></td><"
				+ "/tr>");
		out.println("<tr>" +
				"<td>Release Year:</td>" +
				"<td><input type='text' name='releaseYear' value='"+film.getRelease_Year()+"'id='datepicker'></td>" +
						"</tr>");
		
		
		List<Language> langaugeList=filmserviceimpl.getLanguages();
		
		out.print("<tr><td>Original Language:</td>"
				+ "<td><select name='originalLang' value='"+film.getOriginal_Langauges()+"'>");
		for(Language lang:langaugeList){
			if(lang.getLanguage_Name().equals(film.getOriginal_Langauges().getLanguage_Name())){
				out.print("<option value='"+lang.getLanguage_Id()+"' selected>"+lang.getLanguage_Id()+"</option>");
				
			}
			else
			out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+"</option>");
			}
		out.print("</select></td></tr>");
		
		out.println("<tr>" +
				"<td>Rental Duration:</td>" +
				"<td><input type='text' name='rentalduration' value='"+film.getRental_Duration()+"'id='datepicker1'onmouseout='return isValidateRentalDuration()'>" +
				"<div id='renDur_Div' class='errMsg'></div></td>" +
						"</tr>");
		
		out.print("<tr>"
				+ "<td>Length Of Film:</td>"
				+ "<td><input type='text' name='length' size='20' value='"+film.getLength()+"'onmouseout='return isValidLength()'>" +
				"<div id='lengthDiv' class='errMsg'></div></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Replacement Cost:</td>"
				+ "<td><input type='text' name='cost' size='20' class='text' value='"+film.getReplacement_Cost()+"'onmouseout='return  replacementCostValidation()'>" +
				"<div id='replacementDiv' class='errMsg'></div></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Ratings:</td>"
				+ "<td><select name='rating' value='"+film.getRating()+"'>");
				for(int i=0;i<=5;i++){
					if(i==film.getRating()){
						out.print("<option value='"+i+"' selected>"+i+"</option>");
						}
					else
						out.print("<option value='"+i+"' >"+i+"</option>");
				}
				/*+ "<option value='1'>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>	"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"*/
				out.print("</select></td>"
				+ "</tr>");
		
		
		out.print("<tr>"
				+ "<td>Special Features:</td>"
				+ "<td><input type='text' name='specialFeatures' value='"+film.getSpecial_Features()+"' onmouseout='return isValidSpecialFeatures()'>"
				+ "<div id='specialFeaturesDiv' class='errMsg'></div></td>"
				+ "</tr>");
		
		out.print("<tr><td>Category:</td>"
				+ "<td><select name='category'>"
				+ "<option value=''></option>");
			for(Category category1:category){
				
				if(category1.getCategory_Name().equals(film.getCategory().getCategory_Name()))
				{
					
					out.print("<option value='"+category1.getCategory_Id()+"' selected>"+category1.getCategory_Id()+"</option>");
				}
				else
					out.print("<option value='"+category1.getCategory_Id()+"'>"+category1.getCategory_Id()+"</option>");
			}
			out.print("</select></td></tr>");
		
		
		Set<Actor> actor=actorserviceimpl.getActors();
		Set<Actor> actors1=film.getActors();
		

		out.print("<tr><td>Actor:</td>"
				+ "<td><select name='actor' multiple=''>"
				+ "<option value''></option>");
			boolean flag=false;
			int id1=0;
			for(Actor actor1:actor){
				for(Actor actt:actors1){
					
				if(actor1.getActor_First_Name().equals(actt.getActor_First_Name()) && actor1.getActor_Last_Name().equals(actt.getActor_Last_Name())){
					flag=true;
					 id1=actor1.getActor_Id();
				}
					
			}
				if(flag==true && id1==actor1.getActor_Id())
					out.print("<option value='"+actor1.getActor_Id()+"' selected> "+actor1.getActor_First_Name()+" </option>");
				else
					out.print("<option value='"+actor1.getActor_Id()+"' >"+actor1.getActor_First_Name()+" </option>");
				
			}
		out.print("</select></td></tr>");

		
		List<Language> langaugeList1=film.getLanguages();
		out.print("<tr><td>Language:</td>"
				+ "<td><select multiple name='Lang'>"
					+ "<option value=''></option>");
			boolean flag1=false;
			int id2=0;
			for(Language lang:langaugeList){
				
				for(Language lng:langaugeList1){
					
					if(lang.getLanguage_Name().equals(lng.getLanguage_Name())){
						flag1=true;
						 id2=lang.getLanguage_Id();
					}
						
				}
					if(flag1==true && id2==lang.getLanguage_Id())
						out.print("<option value='"+lang.getLanguage_Id()+"' selected>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
					else
						out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
					
				
			}
		out.print("</select></td></tr>");
		out.print("<tr><td><input type='hidden' name='film_id' value='"+Fid+"'");
		
		out.print("<tr><td></td>"
				+ "<td><input class='myBtn' type='submit' value='Update'</td>"
			+ "</tr>");
			
		out.print("</table></form>");
		out.print("</body></html>");
		
					
		
	}
		
		

}
