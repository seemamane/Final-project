package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

public class UserInteraction {

	Scanner sc=new Scanner(System.in);
		
	//Return fully qualified Film Object
	public Film addFilm(List<Language> languages, List<Category> category1, Set<Actor> actors){
		Film film=new Film();
		
		boolean flag=true;
		
		//Get Title and validate it
		String title=null;
			do{
			System.out.println("Enter Film Title");
			title=sc.nextLine();
			flag=Validate.isValidTitle(title);
				if(!flag)
					System.out.println("Invalid Title. Please Enter Valid Title!");
			}while(!flag);
		film.setTitle(title);
		
		
		//Get Description and Validate it
		String description=null;
		System.out.println("Enter Film Description");
		description=sc.nextLine();
		film.setDescription(description);
		
		//Get Release Year and Validate it
		String releaseYear=null;
		Date releaseDate=null;
		boolean date_flag=false;
		do{
			do{
				System.out.println("Enter Film ReleaseYear");
					releaseYear=sc.next();
					flag=Validate.isValiddate(releaseYear);
					if(!flag)
						System.out.println("Invalid Release Date. Please Enter Valid Title!");
				}while(!flag);
				
				Date today=new Date();
				releaseDate=new Date(releaseYear);
				if(releaseDate.before(today)||releaseDate.equals(today))
					date_flag=true;
				
				if(!date_flag)
					System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setRelease_Year(releaseDate);
		
	//Get and Validate Rental Duration
		String rental_Duration=null;
		Date rentalDate=null;
		boolean rental_flag=false;
		do{
				do{
					System.out.println("Enter Film Rental Duration");
					rental_Duration=sc.next();
					flag=Validate.isValiddate(rental_Duration);
					if(!flag)
						System.out.println("Invalid Rental Duration. Please Enter Valid Rental Duration!");
				}while(!flag);
				
				Date today=new Date();
				rentalDate=new Date(rental_Duration);
				if(rentalDate.after(releaseDate))
					rental_flag=true;
				
				if(!rental_flag)
					System.out.println("Invalid Date! Date should be Future Date!");
		}while(!rental_flag);
		film.setRental_Duration(rentalDate);
			
	//Get and Validate Length
		int length=0;
		do{
			System.out.println("Enter Film Length");
			length=sc.nextInt();
			flag=Validate.isValidLength(length);
				if(!flag)
					System.out.println("Invalid Length. Please Enter Valid Length!");
			}while(!flag);
			film.setLength(length);
			
			
		//Get and Validate Rating
		int rating=0;
		do{
			System.out.println("Enter Film Ratings");
			rating=sc.nextInt();
			flag=Validate.isValidRatings(rating);
				if(!flag)
					System.out.println("Invalid Ratings. Please Enter Valid Rating!");
			}while(!flag);
			film.setRating(rating);
			
		//Get and Validate Special Features
		String special_Features=null;
		do{
			System.out.println("Enter Film Special Features");
			special_Features=sc.next();
			flag=Validate.isValidSpecialFeatures(special_Features);
				if(!flag)
					System.out.println("Invalid Special features. Please Enter Valid Special Features!");
			}while(!flag);
			film.setSpecial_Features(special_Features);
			
		//Get Replacement Cost and Validate it
			int replacement_Cost=0;
			System.out.println("Enter Film replacement cost");
			replacement_Cost=sc.nextInt();
				
			film.setReplacement_Cost(replacement_Cost);
				
				
				
				
		//Choose Language
		System.out.println("Choose Original Language");
		Language language= selectLanguage(languages);
		film.setOriginal_Langauges(language);
				
				
		//Add all languages
		List<Language> languages2=new ArrayList<>();
		String choice;
		boolean flag_langs;
			do{
				System.out.println("Choose All Languages for the Film:");
				Language language1= selectLanguage(languages);
						
				flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
				if(!flag_langs)
					languages2.add(language1);
				else
					System.out.println("Language already Exists. Please try other languages!");
						
						
				System.out.println("Wish to add More Languages?[y|n]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			film.setLanguages(languages2);

	//Choose Cactegory
		System.out.println("Choose Category");
		Category category=selectCategory(category1);
		film.setCategory(category);
				

	//Add all Actors
				
	Set<Actor> actors2=new HashSet<>();
		do{
			System.out.println("Choose All Actors for the Film:");
			Actor actor=addActor(actors);
			actors2.add(actor);
					
			System.out.println("Wish to add More Actors?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		film.setActors(actors2);
				
				
		
		return film;
	}
	


	//Choose Valid Language Object from the list of Languages
	public Language selectLanguage(List<Language>  languages){
			
		Language sel_language=null;
		boolean flag;
			do{	
				//Print Langauge Details
				for(Language language:languages)
					System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
				
				System.out.println("Choose the Language:");
				int option=sc.nextInt();
				
				flag=false;
				
				//Check the Language Object
				for(Language language: languages)
				{
					if(option==language.getLanguage_Id())
					{
						sel_language=language;
						flag=true;
						break;
					}
				}
				
				//Print Error Message
				if(!flag)
					System.out.println("Please select valid Language Id");
			}while(!flag);	
			
			return sel_language;
		}
		
	//Choose Valid Category Object from the list of Categories
	public Category selectCategory(List<Category>  categorys){
				
			Category sel_category=null;
			boolean flag;
				do{	
					//Print Category Details
					for(Category cate:categorys)
						System.out.println(cate.getCategory_Id() + "\t" + cate.getCategory_Name());
					
					System.out.println("Choose the Category:");
					int option=sc.nextInt();
					
					flag=false;
					
					//Check the Category Object
					for(Category cate:categorys)
					{
						if(option==cate.getCategory_Id())
						{
							sel_category=cate;
							flag=true;
							break;
						}
					}
					
					//Print Error Message
					if(!flag)
						System.out.println("Please select valid CategoryId");
				}while(!flag);	
				
				return sel_category;
			}
		
		
	//Choose Valid Actor Object from the list of Actors
	public Actor addActor(Set<Actor> actors){
			
			Actor sel_actor=null;
			boolean flag=false;
			
			do{	
			for(Actor actor:actors)
				System.out.println(actor.getActor_Id() + "\t" + actor.getActor_First_Name() + "\t" + actor.getActor_Last_Name());
			
			System.out.println("Choose the Actor:");
			int option=sc.nextInt();
			
			flag=false;
			
			//Check the Actor Object
			for(Actor actor: actors)
			{
				if(option==actor.getActor_Id())
				{
					sel_actor=actor;
					flag=true;
					break;
				}
			}
				
			
			//Print Error Message
			if(!flag)
				System.out.println("Please select valid Actor Id");
			}while(!flag);	
			
			return sel_actor;
		}
		
	//Get all Film Objects
	public void getAllFilm(Collection<Film> lst) {
			
			System.out.println("FilmID \t " +
					"Title \t " +
					"Release Year \t" +
					"Rental Duration \t" +
					"Replacement Cost \t" +
					"Rating \t" +
					"Langauges \t " +
					"Original Language \t" +
					"Category \t" +
					"Actors \t" +
					"Special Features \t" +
					"Description");
			
			for(Film film:lst){
				String languages="";
				for(Language language:film.getLanguages())
					languages=languages+language.getLanguage_Name()+",";
				
				System.out.println(film.getFilmId() + "\t" +
						film.getTitle() + "\t"+
						film.getRelease_Year()+ "\t"+
						film.getRental_Duration()+"\t"+
						film.getReplacement_Cost()+"\t"+
						film.getRating()+"\t"+
						languages+"\t"+
						film.getOriginal_Langauges()+"\t"+
						film.getCategory()+"\t"+
						film.getActors()+"\t"+
						film.getSpecial_Features()+"\t"+
						film.getDescription());
				
				}
			
		}
	
	//Search By Film ID
	public void searchFilm(Collection<Film> lst){
		System.out.println("Please Enter Film Id you want to Search");
		int f_id=sc.nextInt();
		boolean flag=false;
		//check if repository is Empty
		if(lst.isEmpty()){
			
			System.out.println("Film Repository is Empty");
		}
		else
		{		
			for(Film film:lst)
			{
				if(f_id==film.getFilmId())
				{
					System.out.println(film);
					flag=true;
					break;
				}
			}
			if(flag==false)
			System.out.println("Not Found");
		}
		
	}
	
	
	//Search By Film Title
	public void SearchByFilmTitle(Collection<Film> lst){
		String str=null;
		boolean flag=false;
		System.out.println("Enter Film Title You want to Search-->");
		str=sc.next();
		//check if repository is Empty
		if(lst.isEmpty()){
			
			System.out.println("Film Repository is Empty");
		}
		else
		{
			for(Film film:lst)
			{
			if(str.equals(film.getTitle()))
			{
				
				System.out.println(film);
				flag=true;
				break;
				
			}
			}
			if(flag==false)
				System.out.println("Not Found");
		}
	}
	
	//Search By Rating
	public void SearchByRating(Collection<Film> lst){
		
		int count=0;
		System.out.println("Enter Film Title You want to Search-->");
		int rat=sc.nextInt();
		//check if repository is Empty
		if(lst.isEmpty()){
			
			System.out.println("Film Repository is Empty");
		}
		else
		{
			for(Film film:lst)
			{
			if(rat==film.getRating())
			{
				
				System.out.println(film);
				count+=1;
				
			}
			}
			if(count==0)
				System.out.println("Film With Rating" + rat + "Not Found");
		}
		
	}
	
	//Remove Film Record By Film Id
	public void removeFilmByFilmId(Collection<Film> lst){
		System.out.println("Please Enter Film Id you want to Delete-->");
		int f_id=sc.nextInt();
		boolean flag=false;
		//check if repository is Empty
		if(lst.isEmpty()){
			
			System.out.println("Film Repository is Empty");
		}
		else{	
			for(Film film:lst)
			{
				 if(f_id==film.getFilmId())
					{
					//System.out.println(film);
					lst.remove(film);
					System.out.println("Film Object with FilmId" + film.getFilmId()+"Removed");
					flag=true;
					break;
					}
			}
			
		
		if(flag==false)
		System.out.println("Not Found");
		
		}
		
	}
	
	//Remove Film Record By Film Name
		public void removeFilmByFilmName(Collection<Film> lst){
			System.out.println("Please Enter Film Id you want to Delete-->");
			String title=sc.next();
			boolean flag=false;
			//check if repository is Empty
			if(lst.isEmpty()){
				
				System.out.println("Film Repository is Empty");
			}
			else
				{		
				for(Film film:lst)
					{
					 if(title==film.getTitle())
						{
						
						lst.remove(film);
						System.out.println("Film Object with Film Name-->" + film.getTitle()+"Removed");
						flag=true;
						break;
						}
					}
				
			
				if(flag==false)
				System.out.println("Film Not Found");
			}
			
			
		}
		//Remove Film Record By Film Rating
		public void removeFilmByRating(Collection<Film> lst){
			System.out.println("Please Enter Film Rating you want to Delete-->");
			int ratings=sc.nextInt();
			boolean flag=false;
			//check if repository is Empty
			if(lst.isEmpty()){
					
					System.out.println("Film Repository is Empty");
				
				}
			else		
			{
				for(Film film:lst)
				{
				 if(ratings==film.getRating())
					 {
					
						lst.remove(film);
						System.out.println("Film Object with Rating-->" + film.getRating()+"Removed");
						flag=true;
					
					 }
				}
				
				if(flag==false)
				System.out.println("Not Found");
				
			}
			
		}
	
		
}

