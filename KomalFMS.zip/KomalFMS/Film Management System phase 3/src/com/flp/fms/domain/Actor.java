package com.flp.fms.domain;

public class Actor {
	
	//private fields
	private int actor_Id;
	private String actor_First_Name;
	private String actor_Last_Name;

	//No argument Constructor
	public Actor(){
		
		
	}
	//Overloaded Constructor
	public Actor(int actor_Id,String actor_First_Name,String actor_Last_Name){
		
		super();
		this.actor_Id=actor_Id;
		this.actor_First_Name=actor_First_Name;
		this.actor_Last_Name=actor_Last_Name;
		
	}

	//getters and setters 
	public int getActor_Id() {
		return actor_Id;
	}

	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}

	public String getActor_First_Name() {
		return actor_First_Name;
	}

	public void setActor_First_Name(String actor_First_Name) {
		this.actor_First_Name = actor_First_Name;
	}

	public String getActor_Last_Name() {
		return actor_Last_Name;
	}

	public void setActor_Last_Name(String actor_Last_Name) {
		this.actor_Last_Name = actor_Last_Name;
	}

	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", actor_First_Name="
				+ actor_First_Name + ", actor_Last_Name=" + actor_Last_Name
				+ "]";
	}
	
	

}
