CREATE TABLE LANGUAGE (language_id INT PRIMARY KEY AUTO_INCREMENT,
language_name VARCHAR(20) NOT NULL);

CREATE TABLE Actor (Actor_id INT PRIMARY KEY AUTO_INCREMENT,
FirstName VARCHAR(20) NOT NULL,LastName VARCHAR(20) NOT NULL);

CREATE TABLE Category (category_id INT PRIMARY KEY AUTO_INCREMENT,
Category_name VARCHAR(100) NOT NULL);

CREATE TABLE film(film_id INT PRIMARY KEY AUTO_INCREMENT, 
Title VARCHAR(100) NOT NULL,
Description VARCHAR(100),
ReleaseYear DATE NOT NULL,
OriginalLanguage_ID INT REFERENCES LANGUAGE(language_Id),
RentalDuration DATE NOT NULL,
LENGTH INT NOT NULL,
ReplacementCost DOUBLE NOT NULL,
Ratings INT NOT NULL,
SpecialFeatures VARCHAR(100),
Category_ID INT REFERENCES category(category_id));


DROP TABLE film;

CREATE TABLE film_language(filmId INT REFERENCES film(film_id),
language_id INT REFERENCES LANGUAGE(language_Id));


CREATE TABLE film_actors(filmId INT REFERENCES film(film_id),
actor_id INT REFERENCES actors(actor_id));

INSERT INTO LANGUAGE VALUES(1,'Marathi');
INSERT INTO LANGUAGE VALUES(2,'Hindi');
INSERT INTO LANGUAGE VALUES(3,'English');
INSERT INTO LANGUAGE VALUES(4,'Corien');
INSERT INTO LANGUAGE VALUES(5,'Japanis');
INSERT INTO LANGUAGE VALUES(6,'Telgu');
INSERT INTO LANGUAGE VALUES(7,'French');

INSERT INTO Actor VALUES(1,'ShahRukh', 'Khan');
INSERT INTO Actor VALUES(2,'Salman', 'Khan');
INSERT INTO Actor VALUES(3,'Deepika', 'Padukon');
INSERT INTO Actor VALUES(4,'Katrina', 'Kapoor');
INSERT INTO Actor VALUES(5,'Priynka', 'Chopra');
INSERT INTO Actor VALUES(6,'Ranbir', 'Singh');
INSERT INTO Actor VALUES(7,'Ranvir', 'Kapoor');
INSERT INTO Actor VALUES(8,'Kajol', 'Devgan');
INSERT INTO Actor VALUES(9,'Priya', 'Bapat');


INSERT INTO category VALUES(1,'Action');
INSERT INTO category VALUES(2,'Animation');
INSERT INTO category VALUES(3,'Cartoon');
INSERT INTO category VALUES(4,'Classic');
INSERT INTO category VALUES(5,'Comedy');
INSERT INTO category VALUES(6,'Documentry');
INSERT INTO category VALUES(7,'Drama');
INSERT INTO category VALUES(8,'Family');
INSERT INTO category VALUES(9,'Games');
INSERT INTO category VALUES(10,'Horror');
INSERT INTO category VALUES(11,'Sci-Fi');
INSERT INTO category VALUES(12,'Sports');
SELECT * FROM film;
SELECT * FROM LANGUAGE;
SELECT * FROM film_language;
SELECT * FROM film_actors;


