package com.flp.service;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService {
	public List<Language> getLanguage();

	public List<Category> getCategory();

	public int addFilm(Film film);

	public List<Film> getAllFilms();
	public Map<Integer, Film> searchFilms();
	public int removeFilm(int id);
	public int updateFilm(int id,Film film);

	public List<Film> searchFilm(Film film);

}
