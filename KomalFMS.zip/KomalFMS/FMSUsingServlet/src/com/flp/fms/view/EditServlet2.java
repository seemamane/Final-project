package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.service.FilmServiceImp;

/**
 * Servlet implementation class EditServlet2
 */
public class EditServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		int id=Integer.parseInt(request.getParameter("film_id"));
		  FilmServiceImp filmService=new FilmServiceImp();
		  Film film=new Film();
		  
		  film.setTitle(request.getParameter("title"));
		  film.setDescription(request.getParameter("desc"));
		  film.setRealeaseYear(new Date(request.getParameter("release")));
		  film.setSpecialFeatures(request.getParameter("spec"));
		  film.setLength(Integer.parseInt(request.getParameter("length")));
		  film.setReplacementCost(Double.parseDouble(request.getParameter("cost")));
		  film.setRatings(Integer.parseInt(request.getParameter("rating")));
		  film.setRentalDuration(new Date(request.getParameter("rentD")));
		  
		  Language lang=new Language();
		  lang.setLanguage_Id(Integer.parseInt(request.getParameter("orgLang")));
		  film.setOriginalLanguage(lang);
		  
		  
		  Category category=new Category();
		  category.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		  film.setCategory(category);
		  
		
		  
		  String [] actors=request.getParameterValues("actor");
		  List<Actor> actor1=new ArrayList<>();
		  
		  for(String str:actors){
			  Actor act=new Actor();
			  act.setActor_Id(Integer.parseInt(str));
			  actor1.add(act);
			  
		  }
		   film.setActors(actor1);
		   
		   
		   String [] lang1=request.getParameterValues("othrlang");
		   List<Language> langs=new ArrayList<>();
		   for(String lang2:lang1)
		   {
			   Language lang3=new Language();
			   lang3.setLanguage_Id(Integer.parseInt(lang2));
			   langs.add(lang3);
		   }
		  film.setLanguages(langs);
		   System.out.println("update");
		   System.out.println(id);
		   System.out.println(film);
		   
		  int c= filmService.updateFilm(id,film);
		  if(c>0)
			 /* System.out.println("updateds");*/
			  //request.getRequestDispatcher("EditServlet").forward(request, response);
			  
			  response.sendRedirect("EditServlet");
	}

}
