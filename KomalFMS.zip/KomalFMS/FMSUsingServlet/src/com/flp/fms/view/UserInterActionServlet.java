package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.service.ActorServiceImpl;
import com.flp.service.FilmServiceImp;

/**
 * Servlet implementation class UserInterActionServlet
 */
public class UserInterActionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		FilmServiceImp filmService=new FilmServiceImp();
		ActorServiceImpl actorService=new ActorServiceImpl();
		
		
		
		List<Actor> actor=actorService.getActorList();
		List<Language> languages=filmService.getLanguage();
		List<Category> category=filmService.getCategory();
		
		/*System.out.println("Welcome");
		out.println("Welcome");*/
		/*out.print("<head>");
		out.orint("<link rel="stylesheet" type="text/css" href="../css/mystyles.css"><link rel="stylesheet" type="text/css" href="../css/jquery-ui-1.9.2.custom.css">
<link rel="stylesheet" type="text/css" href="../css/jquery-ui-1.9.2.custom.min.css">
<script type="text/javascript" src="../script/jquery-1.8.3.js"></script>
<script type="text/javascript" src="../script/jquery-ui-1.9.2.custom.js"></script>
<script type="text/javascript" src="../script/jquery-ui-1.9.2.custom.min.js"></script> 


<script type="text/javascript" src="../script/datepicker.js"></script>");
*/		
		out.print("<head>");
		out.print("<script type='text/javascript' src='scripts/validate.js'></script>"
				+"<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
				
				+ " <link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
				/*+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.css'>"
				+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"
				+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"*/
				+ "<script type='text/javascript' src='scripts/jquery-1.8.3.js'></script>"
				+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.js'></script>"
				+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.min.js'></script>"
				+ "<script type='text/javascript' src='scripts/dateSelector.js'></script>");
/*">
 ");
*/		out.print("</head>");
		
		out.print("<html>");
		out.print("<body>");
		out.print("<form name='film' method='post' action='AddFilmServlet'>");
		out.print("<h1 align='center'>Fill The Details of Film</h1>");
		out.println("<center> "
				+ "<table>"
				+ "<tr>"
				+ "<td><label>Film Title</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='title' onmouseout='return validateDetails()'>"
				+ "<div id='titleErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td><label>Description</label></td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='desc' cols='25'></textarea></td><"
				+ "/tr>");
		
		out.print("<tr>"
				+ "<td>Release Year</td>"
				+ "<td>:</td><td>"
				+ "	<input type='text' name='release'  id='relYear' />"
				+ "</td>"
				+ "</tr>");
		

		out.print("<tr><td>Original Language</td><td>:</td>"
				+ "<td><select name='orgLang'>");
		for(Language lang:languages){
			out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
		}
		
		out.print("<tr>"
				+ "<td>Rental Duration</td>"
				+ "<td>:</td><td>"
				+ "	<input type='text' name='rentD'  id='rentalDur' />"
				+ "</td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Length Of Film</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='length' size='20'></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Replacement Cost</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='cost' size='20'></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Ratings</td>"
				+ "<td>:</td>"
				+ "<td><select name='rating' onchange='return isratingSelected()'>"
				+ "<option value=''>Select Rating</option>"
				+ "<option value='1'>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>	"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"
				+ "</select></td>"
				+ "</tr>");
		
	out.print("</select></td></tr>");
		out.print("<tr>"
				+ "<td><label>Special Features:</td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='spec' cols='25'></textarea></td>"
				+ "</tr>");
	
	
		
		
	
	out.print("<tr><td>Category</td><td>:</td>"
			+ "<td><select name='category'>"
			+ "<option value''>Select category</option>");
	for(Category category1:category){
		out.print("<option value='"+category1.getCategory_Id()+"'>"+category1.getCategory_Id()+" "+category1.getCategory_Name()+"</option>");
	}
   out.print("</select></td></tr>");

	out.print("<tr><td>Actor</td><td>:</td>"
			+ "<td><select name='actor' multiple=''>"
			+ "<option value''>Select actors</option>");
	for(Actor actor1:actor){
		out.print("<option value='"+actor1.getActor_Id()+"'>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
	}
	out.print("</select></td></tr>");
	
	
	
		out.print("<tr><td>Other Language</td><td>:</td>"
				+ "<td><select name='othrlang' multiple='' class='ui fluid dropdown'>"
				+ "<option value''>Select languages</option>");
		for(Language lang:languages){
			out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
		}
	out.print("</select></td></tr>");
	
	out.print("<tr><td></td>"
			+ "<td><input type='submit' value='Submit'</td>"
			+ "</tr>");
			
	
			
			
		
		out.print("</html");
		
		

	}

}
