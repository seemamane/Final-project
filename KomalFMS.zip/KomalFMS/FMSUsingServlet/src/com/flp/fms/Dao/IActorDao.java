package com.flp.fms.Dao;

import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorDao {
	
	public List<Actor>addActor();

	List<Actor> getActorList();

}
