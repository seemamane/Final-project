package com.flp.fms.Dao;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	
	public List<Language>getOriginalLanguage();
	public List<Category>getCategory();
	public int addFilm(Film film);
	public List<Film> getAllFilms();
	public Map<Integer, Film> searchFilm();
	public int removeFilm(int id);
	public int updateFilm(int id,Film film);

}
