package com.flp.fms.util;

import java.awt.image.TileObserver;
import java.util.Iterator;
import java.util.List;



import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Language;

public class Validate {

	public static boolean isValidFilmTitle(String title) {
		// TODO Auto-generated method stub
		return title.matches("[A-Za-z0-9.,! ]+");
	}

	public static boolean isVaildReleaseDAte(String releaseDate) {
		// TODO Auto-generated method stub
		return releaseDate.matches("[0|1|2|3|]\\d{1}-(jan|feb|mar|apr|jun|jul|aug|sep|oct|dec)-"
				+ "[12][890]\\d{2}");
	}

	public static boolean isVaildRentalDuration(String rentalDuration) {
		// TODO Auto-generated method stub
		return rentalDuration.matches("[0|1|2|3|]\\d{1}-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|dec)-"
				+ "[12][890]\\d{2}");
	}

	public static boolean isValidLength(int len) {
		if(len>0 && len<1000)
			return true;
		else
		return false;
	}

	public static boolean isValidCost(double replacementCost) {
		if(replacementCost>0.0)
			return true;
		else
			return false;
		
	}

	public static boolean isValidRate(int rating) {
	
		if(rating>=1 && rating<=5)
			return true;
		else
			return false;
	}

	
	public static boolean checkDuplicateActorID(List<Actor> actorList1, Actor actor) {
boolean flag=false;
		System.out.println(actor);
		Iterator<Actor>it=actorList1.iterator();
		if(actorList1.isEmpty())
		{
			flag=false;
		}else{
			while(it.hasNext()){
				Actor act=it.next();
				if(actor.equals(act))
				{
					flag=true;
					break;
				}
			}
		}
		return flag;
	}

	public static boolean checkDuplicateLanguage(List<Language> languagesList, Language language1) {
boolean flag=false;
		
		Iterator<Language> itr= languagesList.iterator();
		if(languagesList.isEmpty())
		{
			flag=false;
		}else{
			while(itr.hasNext()){
				Language language2=itr.next();
				if(language1.equals(language2))
				{
					flag=true;
					break;
				}
			}
		}
		return flag;
	}
	
	
	
	}


