$(function(){

	$("#relYear").datepicker({
		
		numberOfMonths:1,
			showWeek:false,
			changeMonth:true,
			changeYear:true,
			showButtonPanel:true,
			maxDate: new Date(),
			dateFormat:"dd-M-yy"
		});
		
		$("#relYear").datepicker("setDate",new Date());
	});

$(function(){

	$("#rentalDur").datepicker({
		
		numberOfMonths:1,
			showWeek:false,
			changeMonth:true,
			changeYear:true,
			showButtonPanel:true,
			dateFormat:"dd-M-yy"
		});
		
		$("#rentalDur").datepicker("setDate",new Date());
	});