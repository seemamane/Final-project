function validateDetails(){
	var flag=true;
	var title=film.title.value;
	/*var upass=myForm.upwd.value;*/
	
	if(title==null|| title=="")
		{
		document.getElementById("titleErr").innerHTML="*Please enter title";
		flag=false;
		}
	else
		document.getElementById("titleErr").innerHTML="";
		
	
	/*if(upass==null||upass=="")
		{
		document.getElementById("upwdErr").innerHTML="*Please enter Password";
		flag=false;
		}
	else
		document.getElementById("upwdErr").innerHTML="";*/
	
	return flag;
}

function isratingSelected(){
	var rating=film.rating.value;
	Boolean flag=true;
	if(rating=="")
		{
		document.getElementById("titleErr").innerHTML="*Please enter title";
		flag=false;
		}
	return flag;
	
}